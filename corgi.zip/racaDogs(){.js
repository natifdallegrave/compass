function racaDogs(){
    const url = `https://dog.ceo/api/breed/${raca}/ images / random`
    var racas = new Array();
    fetch(url)
    .then((res) => {
        if(res.ok){
            return res.json()
        }
        else{
           throw new Error("error") 
        }
    }).then((data) => {racas = data.message;
        for(let raca in racas){
            const imageDiv = document.getElementById("image");
            const dogImg = document.createElement("img");
            dogImg.className = "img";
            dogImg.src= dogs[dog];
            console.log(dogImg);
            imageDiv.appendChild(dogImg);
            // document.body.style.backgroundImage = `url('${dogs}')`
        }
    console.log(dogs)} )
    .catch((error)=>
    console.log(error)
    )
        
        // dogImage
        
    
        
    }
